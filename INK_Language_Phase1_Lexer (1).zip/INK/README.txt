============================================================
   INK Programming Language v0.1
   Write the Future
   
   Created by: IndianBrand Technology
   Location:   Hyderabad, Telangana, India
   Website:    ink-lang.in
   GitHub:     github.com/IndianBrand/ink
   Jai Hind! 🇮🇳
============================================================

WHAT IS INK?
────────────
INK is India's first programming language.

• Speed of C — compiles to native machine code
• Simplicity of Python — easy to read and write
• Safety of Rust — no null crashes, no memory leaks
• File extension: .in — India in every file worldwide
• Written in Assembly — owes credit to NO other language
• Made in Hyderabad, India — 2026

FILE STRUCTURE
──────────────
INK/
├── lexer/
│   └── lexer.asm       ← Phase 1: Tokeniser (COMPLETE)
├── parser/
│   └── parser.asm      ← Phase 2: AST builder (coming)
├── codegen/
│   └── codegen.asm     ← Phase 3: LLVM code gen (coming)
├── stdlib/
│   ├── io.in           ← Standard library (coming)
│   ├── memory.in       ← Memory module (coming)
│   └── text.in         ← Text/string module (coming)
├── tests/
│   └── hello.in        ← Test INK source file
├── build/
│   └── build.sh        ← Build script
└── README.txt          ← This file

HOW TO BUILD
────────────
Step 1 — Install NASM:
  sudo apt install nasm

Step 2 — Build the INK lexer:
  chmod +x build/build.sh
  ./build/build.sh

Step 3 — Run a .in file:
  ./build/output/ink tests/hello.in

WHAT PHASE 1 DOES (LEXER)
──────────────────────────
The Lexer reads your .in source file and breaks it
into tokens — the smallest meaningful pieces of code.

Example:
  Source:   show "Jai Hind!"
  Tokens:   [SHOW] [STRING:"Jai Hind!"] [EOF]

  Source:   let age = 25
  Tokens:   [LET] [IDENT:age] [EQUALS] [INT:25] [EOF]

All 60 token types supported:
  Keywords: show, let, const, fn, return, if, else,
            for, while, loop, break, continue, match,
            type, pub, use, in, or, and, not,
            true, false, none, exists
  Literals: INT, FLOAT, STRING, CHAR
  Operators: + - * / % = == != < > <= >= -> =>
  Symbols:  ( ) { } [ ] : , . .. ? ! | @ #

WHY WRITTEN IN ASSEMBLY?
────────────────────────
INK is the world's first modern programming language
built from x86-64 Assembly language.

Every other language was built using another language:
  Python     → built using C      (C gets credit)
  Rust       → built using OCaml  (OCaml gets credit)
  Go         → built using C      (C gets credit)
  
INK → built using Assembly
Assembly belongs to no single country or company.
Therefore INK owes full credit to:
  George — IndianBrand Technology — Hyderabad — India 🇮🇳

WHAT COMES NEXT
───────────────
Phase 1 (NOW):   Lexer — tokenises .in files ✅
Phase 2 (Next):  Parser — builds Abstract Syntax Tree
Phase 3 (Later): LLVM backend — compiles to machine code
Phase 4 (Later): @system mode — write OS kernels in INK
Phase 5 (Year2): Standard library + self-hosting
Phase 6 (Year2): inkpkg + VS Code extension + public release

INK SAMPLE CODE
───────────────
// hello.in
show "Jai Hind!"

// variables
let name = "George"
let age  = 30

// function
fn greet(name: text) {
    show "Namaste " + name
}

// if/else
if age > 18 {
    show "Adult"
} else {
    show "Young"
}

// loop
for i in 0..10 {
    show i
}

// OS kernel (system mode)
@system
fn kernel_main() {
    show "IndianBrand OS — Jai Hind!"
    loop {
        check_input()
    }
}

============================================================
INK — Write the Future
IndianBrand Technology | Hyderabad, India | inddn.in
Jai Hind! 🇮🇳
============================================================
