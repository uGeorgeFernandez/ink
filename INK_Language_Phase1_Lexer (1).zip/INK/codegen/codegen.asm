; ============================================================
; INK Programming Language — Code Generator
; File: codegen/codegen.asm
; Architecture: x86-64 Assembly (NASM)
;
; Phase 3 — Code Generator
;
; Takes the AST built by the Parser and converts it
; to LLVM IR (Intermediate Representation).
;
; LLVM IR looks like this:
;
;   define i64 @main() {
;   entry:
;     %result = add i64 5, 3
;     ret i64 0
;   }
;
; LLVM then takes this IR and compiles it to real
; machine code for ARM64 (phones) or x86-64 (desktops).
;
; Pipeline:
;   INK source (.in)
;       → Lexer  → Tokens
;       → Parser → AST
;       → Codegen → LLVM IR (.ll file)
;       → llc    → Object file (.o)
;       → clang  → Executable binary
;
; INK — Write the Future
; IndianBrand Technology, Hyderabad, India
; Jai Hind! 🇮🇳
; ============================================================

; ── SYSTEM CALLS ─────────────────────────────────────────────
SYS_WRITE   equ 1
SYS_OPEN    equ 2
SYS_CLOSE   equ 3
SYS_EXIT    equ 60
O_WRONLY    equ 1
O_CREAT     equ 64
O_TRUNC     equ 512
STDOUT      equ 1
STDERR      equ 2

; ── AST NODE TYPES (same as parser) ──────────────────────────
NODE_PROGRAM        equ 1
NODE_LET            equ 2
NODE_CONST          equ 3
NODE_ASSIGN         equ 4
NODE_FN_DEF         equ 5
NODE_FN_CALL        equ 6
NODE_RETURN         equ 7
NODE_IF             equ 8
NODE_WHILE          equ 9
NODE_FOR            equ 10
NODE_LOOP           equ 11
NODE_BREAK          equ 12
NODE_CONTINUE       equ 13
NODE_MATCH          equ 14
NODE_BLOCK          equ 15
NODE_SHOW           equ 16
NODE_USE            equ 17
NODE_TYPE_DEF       equ 18
NODE_BINARY         equ 19
NODE_UNARY          equ 20
NODE_INT_LIT        equ 21
NODE_FLOAT_LIT      equ 22
NODE_STRING_LIT     equ 23
NODE_CHAR_LIT       equ 24
NODE_BOOL_LIT       equ 25
NODE_NONE_LIT       equ 26
NODE_IDENT          equ 27
NODE_FIELD_ACCESS   equ 28
NODE_INDEX          equ 29
NODE_ARRAY_LIT      equ 30
NODE_MAP_LIT        equ 31
NODE_OPTIONAL_CHECK equ 32
NODE_ERROR_HANDLE   equ 33
NODE_TYPE_ANNOT     equ 34
NODE_PARAM          equ 35
NODE_MATCH_ARM      equ 36

; ── BINARY OPERATORS ─────────────────────────────────────────
BINOP_ADD   equ 1
BINOP_SUB   equ 2
BINOP_MUL   equ 3
BINOP_DIV   equ 4
BINOP_MOD   equ 5
BINOP_EQ    equ 6
BINOP_NEQ   equ 7
BINOP_LT    equ 8
BINOP_GT    equ 9
BINOP_LTE   equ 10
BINOP_GTE   equ 11
BINOP_AND   equ 12
BINOP_OR    equ 13
BINOP_RANGE equ 14

; ── NODE STRUCTURE OFFSETS ───────────────────────────────────
NODE_SIZE   equ 64
NODE_TYPE   equ 0
NODE_LEFT   equ 8
NODE_RIGHT  equ 16
NODE_EXTRA  equ 24
NODE_TSTART equ 32
NODE_TLEN   equ 40
NODE_TLINE  equ 48
NODE_NEXT   equ 56

; ── OUTPUT BUFFER ────────────────────────────────────────────
; We write LLVM IR into a memory buffer first
; then write to the .ll output file
MAX_IR      equ 4194304     ; 4MB output buffer

; ── REGISTER COUNTER ─────────────────────────────────────────
; LLVM IR uses SSA form — every value has a unique register
; We count up: %0, %1, %2, %3...
MAX_VARS    equ 10000       ; max variables/registers

; ── VARIABLE TABLE ───────────────────────────────────────────
; Maps variable names to their LLVM register numbers
; Each entry: name_start(8) + name_len(8) + reg_num(8) = 24 bytes
VAR_ENTRY_SIZE  equ 24
MAX_VAR_TABLE   equ 1000    ; max variables in scope

; ── LABEL COUNTER ────────────────────────────────────────────
; For generating unique labels: if.then.0, if.else.0, loop.0 etc

; ── DATA SECTION ─────────────────────────────────────────────
section .data

    ; Status messages
    msg_codegen     db  "[INK] Generating LLVM IR...", 10, 0
    msg_codegen_ok  db  "[INK] LLVM IR generated successfully!", 10, 0
    msg_codegen_err db  "[INK ERROR] Code generation failed.", 10, 0
    msg_writing     db  "[INK] Writing IR to output file...", 10, 0
    msg_write_ok    db  "[INK] Written to output.ll", 10, 0
    msg_compiling   db  "[INK] Compiling with LLVM...", 10, 0
    msg_done        db  "[INK] Compilation complete! Binary ready.", 10, 0

    ; LLVM IR boilerplate — start of every .ll file
    ir_header       db  "; INK Language — Generated LLVM IR", 10
                    db  "; IndianBrand Technology, Hyderabad, India", 10
                    db  "; Write the Future | Jai Hind!", 10
                    db  10, 0
    ir_header_len   equ $ - ir_header

    ; Target triple for x86-64 Linux
    ir_target       db  'target triple = "x86_64-pc-linux-gnu"', 10
                    db  10, 0
    ir_target_len   equ $ - ir_target

    ; Standard type declarations
    ir_types        db  "; Standard types", 10
                    db  "; int = i64, float = double, bool = i1, text = i8*", 10
                    db  10, 0

    ; Printf declaration for show statement
    ir_printf_decl  db  'declare i32 @printf(i8* nocapture, ...)', 10
                    db  10, 0
    ir_printf_len   equ $ - ir_printf_decl

    ; String format constants
    ir_fmt_int      db  '@.fmt.int = private constant [4 x i8] c"%ld\00"', 10, 0
    ir_fmt_str      db  '@.fmt.str = private constant [3 x i8] c"%s\00"', 10, 0
    ir_fmt_nl       db  '@.fmt.newline = private constant [2 x i8] c"\0A\00"', 10, 0

    ; Main function start
    ir_main_start   db  "define i64 @main() {", 10
                    db  "entry:", 10, 0
    ir_main_end     db  "  ret i64 0", 10
                    db  "}", 10, 0

    ; LLVM IR instruction templates
    ; Add instruction
    ir_add          db  "  %", 0
    ir_add_mid      db  " = add i64 %", 0
    ir_add_comma    db  ", %", 0

    ; Sub instruction
    ir_sub_op       db  " = sub i64 %", 0

    ; Mul instruction
    ir_mul_op       db  " = mul i64 %", 0

    ; Div instruction
    ir_div_op       db  " = sdiv i64 %", 0

    ; Alloca — allocate variable on stack
    ir_alloca       db  "  %", 0
    ir_alloca_type  db  " = alloca i64", 10, 0

    ; Store — write value to variable
    ir_store        db  "  store i64 %", 0
    ir_store_to     db  ", i64* %", 0
    ir_newline      db  10, 0

    ; Load — read value from variable
    ir_load         db  "  %", 0
    ir_load_from    db  " = load i64, i64* %", 0

    ; Call printf for show
    ir_call_printf  db  "  call i32 (i8*, ...) @printf(i8* getelementptr inbounds ", 0
    ir_call_arg     db  ", i64 %", 0
    ir_call_end     db  ")", 10, 0

    ; Branch instructions
    ir_br           db  "  br label %", 0
    ir_br_cond      db  "  br i1 %", 0
    ir_br_then      db  ", label %", 0
    ir_br_else      db  ", label %", 0
    ir_label        db  10, 0  ; newline before label

    ; Compare instructions
    ir_icmp_eq      db  " = icmp eq i64 %", 0
    ir_icmp_ne      db  " = icmp ne i64 %", 0
    ir_icmp_lt      db  " = icmp slt i64 %", 0
    ir_icmp_gt      db  " = icmp sgt i64 %", 0
    ir_icmp_le      db  " = icmp sle i64 %", 0
    ir_icmp_ge      db  " = icmp sge i64 %", 0

    ; Function definition
    ir_fn_start     db  "define i64 @", 0
    ir_fn_args      db  "() {", 10
                    db  "entry:", 10, 0
    ir_fn_end       db  "  ret i64 0", 10
                    db  "}", 10, 10, 0

    ; Return instruction
    ir_ret          db  "  ret i64 %", 0

    ; Output filename
    out_filename    db  "output.ll", 0
    out_mode        equ O_WRONLY | O_CREAT | O_TRUNC
    out_perms       equ 0o644

    ; Numbers as strings for register names
    digits          db  "0123456789"

; ── BSS SECTION ──────────────────────────────────────────────

    ; Inline IR strings
    cstr_0 db "  br label %break.target", 10, 0
    cstr_1 db "  %", 0
    cstr_2 db " = alloca i64", 10, 0
    cstr_3 db "  store i64 %", 0
    cstr_4 db ", i64* %", 0
    cstr_5 db 10, 0
    cstr_6 db "  store i64 %", 0
    cstr_7 db ", i64* %", 0
    cstr_8 db 10, 0
    cstr_9 db "call i32 (i8*, ...) @printf(i8* getelementptr inbounds ([4 x i8], [4 x i8]* @.fmt.int, i32 0, i32 0), i64 %", 0
    cstr_10 db ")", 10, 0
    cstr_11 db "call i32 (i8*, ...) @printf(i8* getelementptr inbounds ([2 x i8], [2 x i8]* @.fmt.newline, i32 0, i32 0))", 10, 0
    cstr_12 db "call i32 (i8*, ...) @printf(i8* getelementptr inbounds ([3 x i8], [3 x i8]* @.fmt.str, i32 0, i32 0), i8* %", 0
    cstr_13 db ")", 10, 0
    cstr_14 db "call i32 (i8*, ...) @printf(i8* getelementptr inbounds ([2 x i8], [2 x i8]* @.fmt.newline, i32 0, i32 0))", 10, 0
    cstr_15 db "  %", 0
    cstr_16 db " = add i64 0, ", 0
    cstr_17 db 10, 0
    cstr_18 db "  %", 0
    cstr_19 db " = fadd double 0.0, ", 0
    cstr_20 db 10, 0
    cstr_21 db "  %", 0
    cstr_22 db " = getelementptr inbounds [", 0
    cstr_23 db " x i8], [", 0
    cstr_24 db " x i8]* @.str.", 0
    cstr_25 db ", i32 0, i32 0", 10, 0
    cstr_26 db "  %", 0
    cstr_27 db " = add i1 0, ", 0
    cstr_28 db 10, 0
    cstr_29 db "  %", 0
    cstr_30 db " = load i64, i64* %", 0
    cstr_31 db 10, 0
    cstr_32 db "  %", 0
    cstr_33 db " = add i64 %", 0
    cstr_34 db " = sub i64 %", 0
    cstr_35 db " = mul i64 %", 0
    cstr_36 db " = sdiv i64 %", 0
    cstr_37 db " = srem i64 %", 0
    cstr_38 db " = icmp eq i64 %", 0
    cstr_39 db " = icmp ne i64 %", 0
    cstr_40 db " = icmp slt i64 %", 0
    cstr_41 db " = icmp sgt i64 %", 0
    cstr_42 db " = icmp sle i64 %", 0
    cstr_43 db " = icmp sge i64 %", 0
    cstr_44 db ", %", 0
    cstr_eq db " = ", 0
    cstr_45 db 10, 0
    cstr_46 db "  %", 0
    cstr_47 db " = sub i64 0, %", 0
    cstr_48 db " = xor i1 %", 0
    cstr_49 db ", true", 0
    cstr_50 db 10, 0
    cstr_51 db "  br i1 %", 0
    cstr_52 db ", label %if.then.", 0
    cstr_53 db ", label %if.else.", 0
    cstr_54 db 10, 0
    cstr_55 db 10, 0
    cstr_56 db "if.then.", 0
    cstr_57 db ":", 10, 0
    cstr_58 db "  br label %if.end.", 0
    cstr_59 db 10, 0
    cstr_60 db 10, 0
    cstr_61 db "if.else.", 0
    cstr_62 db ":", 10, 0
    cstr_63 db "  br label %if.end.", 0
    cstr_64 db 10, 0
    cstr_65 db 10, 0
    cstr_66 db "if.end.", 0
    cstr_67 db ":", 10, 0
    cstr_68 db "  br label %while.cond.", 0
    cstr_69 db 10, 0
    cstr_70 db 10, 0
    cstr_71 db "while.cond.", 0
    cstr_72 db ":", 10, 0
    cstr_73 db "  br i1 %", 0
    cstr_74 db ", label %while.body.", 0
    cstr_75 db ", label %while.end.", 0
    cstr_76 db 10, 0
    cstr_77 db 10, 0
    cstr_78 db "while.body.", 0
    cstr_79 db ":", 10, 0
    cstr_80 db "  br label %while.cond.", 0
    cstr_81 db 10, 0
    cstr_82 db 10, 0
    cstr_83 db "while.end.", 0
    cstr_84 db ":", 10, 0
    cstr_85 db "  %", 0
    cstr_86 db " = alloca i64", 10, 0
    cstr_87 db "  store i64 %", 0
    cstr_88 db ", i64* %", 0
    cstr_89 db 10, 0
    cstr_90 db "  br label %for.cond.", 0
    cstr_91 db 10, 0
    cstr_92 db 10, 0
    cstr_93 db "for.cond.", 0
    cstr_94 db ":", 10, 0
    cstr_95 db "  %", 0
    cstr_96 db " = load i64, i64* %", 0
    cstr_97 db 10, 0
    cstr_98 db "  %", 0
    cstr_99 db " = icmp slt i64 %", 0
    cstr_100 db ", %", 0
    cstr_101 db 10, 0
    cstr_102 db "  br i1 %", 0
    cstr_103 db ", label %for.body.", 0
    cstr_104 db ", label %for.end.", 0
    cstr_105 db 10, 0
    cstr_106 db 10, 0
    cstr_107 db "for.body.", 0
    cstr_108 db ":", 10, 0
    cstr_109 db "  %", 0
    cstr_110 db " = add i64 %", 0
    cstr_111 db "  %", 0
    cstr_112 db " = load i64, i64* %", 0
    cstr_113 db 10, 0
    cstr_114 db "  %", 0
    cstr_115 db " = add i64 %", 0
    cstr_116 db ", 1", 10, 0
    cstr_117 db "  store i64 %", 0
    cstr_118 db ", i64* %", 0
    cstr_119 db 10, 0
    cstr_120 db "  br label %for.cond.", 0
    cstr_121 db 10, 0
    cstr_122 db 10, 0
    cstr_123 db "for.end.", 0
    cstr_124 db ":", 10, 0
    cstr_125 db "  br label %loop.start.", 0
    cstr_126 db 10, 0
    cstr_127 db 10, 0
    cstr_128 db "loop.start.", 0
    cstr_129 db ":", 10, 0
    cstr_130 db "  br label %loop.start.", 0
    cstr_131 db 10, 0
    cstr_132 db 10, 0
    cstr_133 db "loop.end.", 0
    cstr_134 db ":", 10, 0
    cstr_135 db "  br label %fn.skip.", 0
    cstr_136 db 10, 0
    cstr_137 db 10, 0
    cstr_138 db "define i64 @", 0
    cstr_139 db "() {", 10
    cstr_140 db "  ret i64 0", 10
    cstr_141 db "fn.skip.", 0
    cstr_142 db ":", 10, 0
    cstr_143 db "  %", 0
    cstr_144 db " = call i64 @", 0
    cstr_145 db "()", 10, 0
    cstr_146 db "  ret i64 %", 0
    cstr_147 db 10, 0
    cstr_148 db "  ret i64 0", 10, 0
    cstr_149 db 10, "; String literal constants", 10, 0
    cstr_150 db "@.str.", 0
    cstr_151 db " = private constant [", 0
    cstr_152 db " x i8] c", 0x22, 0
    cstr_153 db "\00", 0x22, 10, 0


    ; For loop string constants
    cstr_alloca_pfx db "  %", 0
    cstr_alloca_sfx db " = alloca i64", 10, 0
    cstr_store_pfx db "  store i64 %", 0
    cstr_store_mid db ", i64* %", 0
    cstr_nl db 10, 0
    cstr_br_label db "  br label %", 0
    cstr_for_cond db "for.cond.", 0
    cstr_colon_nl db ":", 10, 0
    cstr_pct db "  %", 0
    cstr_load_i64 db " = load i64, i64* %", 0
    cstr_icmp_slt db " = icmp slt i64 %", 0
    cstr_comma_pct db ", %", 0
    cstr_lbl_comma db ", label %", 0
    cstr_for_body_lbl db "for.body.", 0
    cstr_for_end_lbl db "for.end.", 0
    cstr_add_i64_pct db " = add i64 %", 0
    cstr_comma_1_nl db ", 1", 10, 0

    ; Phase 4 additional strings
    cstr_load db " = load i64, i64* %", 0
    cstr_icmp_lt db " = icmp slt i64 %", 0
    cstr_br_i1 db "  br i1 %", 0
    cstr_lbl_then db ", label %for.body.", 0
    cstr_lbl_else db ", label %for.end.", 0
    cstr_for_body db "for.body.", 0
    cstr_for_end db "for.end.", 0
    cstr_add_i64 db " = add i64 %", 0
    cstr_comma1 db ", 1", 10, 0

section .bss
    for_end_reg   resq 1   ; end register number
    for_ctr_reg   resq 1   ; counter alloca register
    for_loaded_reg resq 1  ; loaded value register (temp)
    for_inc_reg   resq 1   ; incremented value register (temp)
    for_ctr_alloca resq 1  ; the actual counter alloca register (permanent)
    for_cur_reg    resq 1  ; current value register
    for_cmp_reg    resq 1  ; compare result register

    ; LLVM IR output buffer
    ir_buf          resb    MAX_IR

    ; Current position in IR buffer
    ir_pos          resq    1

    ; Register counter — current SSA register number
    reg_counter     resq    1

    ; Label counter — for unique branch labels
    label_counter   resq    1

    ; Variable table
    var_table       resb    MAX_VAR_TABLE * VAR_ENTRY_SIZE

    ; Number of variables in table
    var_count       resq    1

    ; Pointer to source buffer (for reading token text)
    cg_src_buf      resq    1

    ; Current function name buffer
    cur_fn_name     resb    256
    cur_fn_len      resq    1

    ; Temporary number buffer for converting ints to strings
    num_buf         resb    32

    ; Output file descriptor
    out_fd          resq    1

    ; String literal counter for unique global names
    str_lit_count   resq    1

    ; String literal storage — global string constants in IR
    ; Each string literal becomes a global in LLVM IR
    str_lit_buf     resb    65536   ; 64KB for string literals section

    ; Position in string literal buffer
    str_lit_pos     resq    1

; ── TEXT SECTION ─────────────────────────────────────────────
section .text
    global codegen_init
    global ink_codegen
    global codegen_write_output

; ============================================================
; CODEGEN_INIT
; Initialises code generator state
; Input: rdi = pointer to source buffer
; ============================================================
codegen_init:
    push    rbp
    mov     rbp, rsp

    mov     [cg_src_buf], rdi   ; save source buffer pointer

    ; Reset all counters
    mov     qword [ir_pos],        0
    mov     qword [reg_counter],   0
    mov     qword [label_counter], 0
    mov     qword [var_count],     0
    mov     qword [str_lit_count], 0
    mov     qword [str_lit_pos],   0

    pop     rbp
    ret

; ============================================================
; INK_CODEGEN — main code generation entry point
; Input: rdi = pointer to root AST node (PROGRAM node)
; Returns: rax = 1 if success, 0 if error
; ============================================================
ink_codegen:
    push    rbp
    mov     rbp, rsp
    push    rbx
    push    r12

    mov     r12, rdi            ; save root node

    ; Print status message
    mov     rdi, msg_codegen
    call    cg_print_str

    ; Write LLVM IR header
    call    emit_header

    ; Generate code for entire program
    mov     rdi, r12
    call    codegen_program

    ; Write main function end
    call    emit_main_end

    ; Write all string literals (global constants)
    call    emit_string_globals

    ; Success
    mov     rdi, msg_codegen_ok
    call    cg_print_str

    mov     rax, 1

    pop     r12
    pop     rbx
    pop     rbp
    ret

; ============================================================
; EMIT_HEADER
; Writes the LLVM IR file header
; ============================================================
emit_header:
    push    rbp
    mov     rbp, rsp

    ; Write comment header
    mov     rdi, ir_header
    call    emit_str

    ; Write target triple
    mov     rdi, ir_target
    call    emit_str

    ; Write printf declaration
    mov     rdi, ir_printf_decl
    call    emit_str

    ; Write format string declarations
    mov     rdi, ir_fmt_int
    call    emit_str
    mov     rdi, ir_fmt_str
    call    emit_str
    mov     rdi, ir_fmt_nl
    call    emit_str

    ; Write newline separator
    mov     rdi, ir_newline
    call    emit_str

    ; Write main function start
    mov     rdi, ir_main_start
    call    emit_str

    pop     rbp
    ret

; ============================================================
; EMIT_MAIN_END
; Writes closing of main function
; ============================================================
emit_main_end:
    push    rbp
    mov     rbp, rsp

    mov     rdi, ir_main_end
    call    emit_str

    pop     rbp
    ret

; ============================================================
; CODEGEN_PROGRAM
; Generates code for PROGRAM node
; Input: rdi = PROGRAM node pointer
; ============================================================
codegen_program:
    push    rbp
    mov     rbp, rsp
    push    r12

    mov     r12, rdi

    ; Get first statement (left child)
    mov     r12, [r12 + NODE_LEFT]

.stmt_loop:
    test    r12, r12
    jz      .done               ; no more statements

    ; Generate code for this statement
    mov     rdi, r12
    call    codegen_node

    ; Move to next sibling
    mov     r12, [r12 + NODE_NEXT]
    jmp     .stmt_loop

.done:
    pop     r12
    pop     rbp
    ret

; ============================================================
; CODEGEN_NODE
; Dispatches to correct codegen function based on node type
; Input: rdi = AST node pointer
; Returns: rax = LLVM register number holding the result
; ============================================================
codegen_node:
    push    rbp
    mov     rbp, rsp
    push    rbx

    test    rdi, rdi
    jz      .null_node

    mov     rbx, rdi            ; save node pointer
    mov     rax, [rdi + NODE_TYPE]  ; get node type

    cmp     rax, NODE_LET
    je      .do_let

    cmp     rax, NODE_CONST
    je      .do_const

    cmp     rax, NODE_FN_DEF
    je      .do_fn_def

    cmp     rax, NODE_FN_CALL
    je      .do_fn_call

    cmp     rax, NODE_RETURN
    je      .do_return

    cmp     rax, NODE_IF
    je      .do_if

    cmp     rax, NODE_WHILE
    je      .do_while

    cmp     rax, NODE_FOR
    je      .do_for

    cmp     rax, NODE_LOOP
    je      .do_loop

    cmp     rax, NODE_BREAK
    je      .do_break

    cmp     rax, NODE_SHOW
    je      .do_show

    cmp     rax, NODE_BINARY
    je      .do_binary

    cmp     rax, NODE_UNARY
    je      .do_unary

    cmp     rax, NODE_INT_LIT
    je      .do_int_lit

    cmp     rax, NODE_FLOAT_LIT
    je      .do_float_lit

    cmp     rax, NODE_STRING_LIT
    je      .do_string_lit

    cmp     rax, NODE_BOOL_LIT
    je      .do_bool_lit

    cmp     rax, NODE_IDENT
    je      .do_ident

    cmp     rax, NODE_BLOCK
    je      .do_block

    cmp     rax, NODE_ASSIGN
    je      .do_assign

    ; Unknown node — skip
    xor     rax, rax
    jmp     .done

.do_let:
    mov     rdi, rbx
    call    codegen_let
    jmp     .done

.do_const:
    mov     rdi, rbx
    call    codegen_let         ; const is same as let for now
    jmp     .done

.do_fn_def:
    mov     rdi, rbx
    call    codegen_fn_def
    jmp     .done

.do_fn_call:
    mov     rdi, rbx
    call    codegen_fn_call
    jmp     .done

.do_return:
    mov     rdi, rbx
    call    codegen_return
    jmp     .done

.do_if:
    mov     rdi, rbx
    call    codegen_if
    jmp     .done

.do_while:
    mov     rdi, rbx
    call    codegen_while
    jmp     .done

.do_for:
    mov     rdi, rbx
    call    codegen_for
    jmp     .done

.do_loop:
    mov     rdi, rbx
    call    codegen_loop
    jmp     .done

.do_break:
    ; break — for now emit unreachable
    mov     rdi, cstr_0
    call    emit_str
    xor     rax, rax
    jmp     .done

.do_show:
    mov     rdi, rbx
    call    codegen_show
    jmp     .done

.do_binary:
    mov     rdi, rbx
    call    codegen_binary
    jmp     .done

.do_unary:
    mov     rdi, rbx
    call    codegen_unary
    jmp     .done

.do_int_lit:
    mov     rdi, rbx
    call    codegen_int_lit
    jmp     .done

.do_float_lit:
    mov     rdi, rbx
    call    codegen_float_lit
    jmp     .done

.do_string_lit:
    mov     rdi, rbx
    call    codegen_string_lit
    jmp     .done

.do_bool_lit:
    mov     rdi, rbx
    call    codegen_bool_lit
    jmp     .done

.do_ident:
    mov     rdi, rbx
    call    codegen_ident
    jmp     .done

.do_block:
    mov     rdi, rbx
    call    codegen_block
    jmp     .done

.do_assign:
    mov     rdi, rbx
    call    codegen_assign
    jmp     .done

.null_node:
    xor     rax, rax

.done:
    pop     rbx
    pop     rbp
    ret

; ============================================================
; CODEGEN_LET
; Generates: let name = expr
;
; LLVM IR output:
;   %name = alloca i64          ; allocate on stack
;   %val = ... (expr result)    ; evaluate expression
;   store i64 %val, i64* %name  ; store value
; ============================================================
codegen_let:
    push    rbp
    mov     rbp, rsp
    push    rbx
    push    r12
    push    r13

    mov     r12, rdi            ; r12 = LET node

    ; Get variable name node (left child)
    mov     r13, [r12 + NODE_LEFT]  ; r13 = IDENT node

    ; Allocate a new register for this variable
    call    new_reg
    mov     rbx, rax            ; rbx = register number

    ; Register this variable in the var table
    mov     rdi, r13            ; ident node
    mov     rsi, rbx            ; register number
    call    var_table_add

    ; Emit: %reg = alloca i64
    mov     rdi, cstr_1
    call    emit_str
    mov     rdi, rbx
    call    emit_num
    mov     rdi, cstr_2
    call    emit_str

    ; Generate code for the right-hand side expression
    mov     rdi, [r12 + NODE_RIGHT]
    call    codegen_node
    push    rax                 ; save RHS result register

    ; Emit: store i64 %val_reg, i64* %var_reg
    mov     rdi, cstr_3
    call    emit_str
    pop     rdi                 ; value register (from RHS)
    push    rdi
    call    emit_num
    mov     rdi, cstr_4
    call    emit_str
    ; Get variable alloca register from var table
    mov     rdi, [r12 + NODE_LEFT]
    call    var_table_get
    push    rax                 ; save alloca reg
    mov     rdi, rax
    call    emit_num
    pop     rax                 ; restore alloca reg
    pop     rdi                 ; restore value reg
    mov     rdi, cstr_5
    call    emit_str

    xor     rax, rax

    pop     r13
    pop     r12
    pop     rbx
    pop     rbp
    ret

; ============================================================
; CODEGEN_ASSIGN
; Generates: name = expr
; ============================================================
codegen_assign:
    push    rbp
    mov     rbp, rsp
    push    r12

    mov     r12, rdi

    ; Evaluate right side
    mov     rdi, [r12 + NODE_RIGHT]
    call    codegen_node
    push    rax                 ; save value register

    ; Get variable register
    mov     rdi, [r12 + NODE_LEFT]
    call    var_table_get
    mov     rbx, rax            ; var register

    ; Emit store
    mov     rdi, cstr_6
    call    emit_str
    pop     rdi
    call    emit_num
    mov     rdi, cstr_7
    call    emit_str
    mov     rdi, rbx
    call    emit_num
    mov     rdi, cstr_8
    call    emit_str

    xor     rax, rax
    pop     r12
    pop     rbp
    ret

; ============================================================
; CODEGEN_SHOW
; Generates: show expr
;
; LLVM IR output:
;   %val = ... (expression)
;   call i32 @printf("%ld\n", %val)
; ============================================================
codegen_show:
    push    rbp
    mov     rbp, rsp
    push    rbx
    push    r12
    push    r13

    mov     r12, rdi            ; r12 = SHOW node

    ; Get left child node and check its type BEFORE codegen
    mov     rax, [r12 + NODE_LEFT]
    test    rax, rax
    jz      .done

    ; Save node type for later
    mov     rbx, [rax + NODE_TYPE]  ; rbx = child node type

    ; Generate the expression to show
    mov     rdi, rax
    call    codegen_node
    mov     r13, rax            ; r13 = result register

    cmp     rbx, NODE_STRING_LIT
    je      .show_string

    ; Show as integer — %N = call i32 @printf(fmt, val)
    mov     rdi, cstr_32        ; "  %"
    call    emit_str
    call    new_reg
    push    rax
    mov     rdi, rax
    call    emit_num
    mov     rdi, cstr_eq
    call    emit_str
    mov     rdi, cstr_9
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_10
    call    emit_str
    pop     rax

    ; Print newline — %N = call i32 @printf(newline)
    mov     rdi, cstr_32        ; "  %"
    call    emit_str
    call    new_reg
    push    rax
    mov     rdi, rax
    call    emit_num
    mov     rdi, cstr_eq
    call    emit_str
    mov     rdi, cstr_11
    call    emit_str
    pop     rax
    jmp     .done

.show_string:
    ; Show as string — %N = call i32 @printf(fmt, ptr)
    mov     rdi, cstr_32
    call    emit_str
    call    new_reg
    push    rax
    mov     rdi, rax
    call    emit_num
    mov     rdi, cstr_eq
    call    emit_str
    mov     rdi, cstr_12
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_13
    call    emit_str
    pop     rax

    ; Print newline
    mov     rdi, cstr_32
    call    emit_str
    call    new_reg
    push    rax
    mov     rdi, rax
    call    emit_num
    mov     rdi, cstr_eq
    call    emit_str
    mov     rdi, cstr_14
    call    emit_str
    pop     rax

.done:
    xor     rax, rax
    pop     r13
    pop     r12
    pop     rbx
    pop     rbp
    ret

; ============================================================
; CODEGEN_INT_LIT
; Generates code for integer literal: 42
;
; LLVM IR output:
;   %reg = add i64 0, 42    ; load constant into register
; ============================================================
codegen_int_lit:
    push    rbp
    mov     rbp, rsp
    push    r12

    mov     r12, rdi            ; r12 = INT_LIT node

    ; Allocate new register
    call    new_reg
    push    rax                 ; save register number

    ; Emit: %reg = add i64 0, <value>
    mov     rdi, cstr_15
    call    emit_str
    mov     rdi, [rsp]
    call    emit_num
    mov     rdi, cstr_16
    call    emit_str

    ; Get the actual integer value from source
    mov     rdi, [r12 + NODE_TSTART]   ; start position
    mov     rsi, [r12 + NODE_TLEN]     ; length
    call    emit_source_text

    mov     rdi, cstr_17
    call    emit_str

    pop     rax                 ; return register number

    pop     r12
    pop     rbp
    ret

; ============================================================
; CODEGEN_FLOAT_LIT
; Generates code for float literal: 3.14
; ============================================================
codegen_float_lit:
    push    rbp
    mov     rbp, rsp
    push    r12

    mov     r12, rdi

    call    new_reg
    push    rax

    ; For floats — use double type in LLVM
    mov     rdi, cstr_18
    call    emit_str
    mov     rdi, [rsp]
    call    emit_num
    mov     rdi, cstr_19
    call    emit_str

    mov     rdi, [r12 + NODE_TSTART]
    mov     rsi, [r12 + NODE_TLEN]
    call    emit_source_text

    mov     rdi, cstr_20
    call    emit_str

    pop     rax
    pop     r12
    pop     rbp
    ret

; ============================================================
; CODEGEN_STRING_LIT
; Generates code for string literal: "Jai Hind!"
;
; LLVM IR output (global):
;   @.str.0 = private constant [10 x i8] c"Jai Hind!\00"
;
; Usage:
;   %reg = getelementptr [10 x i8], [10 x i8]* @.str.0, i32 0, i32 0
; ============================================================
codegen_string_lit:
    push    rbp
    mov     rbp, rsp
    push    r12
    push    r13

    mov     r12, rdi            ; r12 = STRING_LIT node

    ; Get string literal index
    mov     r13, [str_lit_count]
    inc     qword [str_lit_count]

    ; Save this string literal for later global emission
    ; Store: str_start, str_len, str_index in str_lit_buf
    mov     rax, [str_lit_pos]
    mov     rbx, [r12 + NODE_TSTART]
    mov     [str_lit_buf + rax], rbx
    add     rax, 8
    mov     rbx, [r12 + NODE_TLEN]
    mov     [str_lit_buf + rax], rbx
    add     rax, 8
    mov     [str_lit_buf + rax], r13
    add     rax, 8
    mov     [str_lit_pos], rax

    ; Allocate register for the pointer
    call    new_reg
    push    rax

    ; Emit: %reg = getelementptr...
    mov     rdi, cstr_21
    call    emit_str
    mov     rdi, [rsp]
    call    emit_num
    mov     rdi, cstr_22
    call    emit_str

    ; String length + 1 for null terminator
    mov     rdi, [r12 + NODE_TLEN]
    inc     rdi
    call    emit_num

    mov     rdi, cstr_23
    call    emit_str

    mov     rdi, [r12 + NODE_TLEN]
    inc     rdi
    call    emit_num

    mov     rdi, cstr_24
    call    emit_str
    mov     rdi, r13
    call    emit_num

    mov     rdi, cstr_25
    call    emit_str

    pop     rax
    pop     r13
    pop     r12
    pop     rbp
    ret

; ============================================================
; CODEGEN_BOOL_LIT
; Generates code for bool literal: true / false
; ============================================================
codegen_bool_lit:
    push    rbp
    mov     rbp, rsp
    push    r12

    mov     r12, rdi

    call    new_reg
    push    rax

    mov     rdi, cstr_26
    call    emit_str
    mov     rdi, [rsp]
    call    emit_num
    mov     rdi, cstr_27
    call    emit_str

    ; extra = 1 for true, 0 for false
    mov     rdi, [r12 + NODE_EXTRA]
    call    emit_num

    mov     rdi, cstr_28
    call    emit_str

    pop     rax
    pop     r12
    pop     rbp
    ret

; ============================================================
; CODEGEN_IDENT
; Generates code to load a variable: name
;
; LLVM IR output:
;   %reg = load i64, i64* %var_reg
; ============================================================
codegen_ident:
    push    rbp
    mov     rbp, rsp
    push    r12
    push    r13

    mov     r12, rdi            ; r12 = IDENT node

    ; Look up variable in table to get its alloca register
    mov     rdi, r12
    call    var_table_get
    mov     r13, rax            ; r13 = alloca register

    ; Allocate new register for loaded value
    call    new_reg
    push    rax

    ; Emit: %new_reg = load i64, i64* %alloca_reg
    mov     rdi, cstr_29
    call    emit_str
    mov     rdi, [rsp]
    call    emit_num
    mov     rdi, cstr_30
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_31
    call    emit_str

    pop     rax
    pop     r13
    pop     r12
    pop     rbp
    ret

; ============================================================
; CODEGEN_BINARY
; Generates code for binary expression: a + b, a == b etc
;
; LLVM IR output:
;   %left  = ... (left expression)
;   %right = ... (right expression)
;   %result = add i64 %left, %right
; ============================================================
codegen_binary:
    push    rbp
    mov     rbp, rsp
    push    rbx
    push    r12
    push    r13
    push    r14

    mov     r12, rdi            ; r12 = BINARY node

    ; Generate left side
    mov     rdi, [r12 + NODE_LEFT]
    call    codegen_node
    mov     r13, rax            ; r13 = left register

    ; Generate right side
    mov     rdi, [r12 + NODE_RIGHT]
    call    codegen_node
    mov     r14, rax            ; r14 = right register

    ; Get operator
    mov     rbx, [r12 + NODE_EXTRA]

    ; Allocate result register
    call    new_reg
    push    rax                 ; save result register

    ; Emit the operation
    mov     rdi, cstr_32
    call    emit_str
    mov     rdi, [rsp]
    call    emit_num

    ; Choose LLVM instruction based on operator
    cmp     rbx, BINOP_ADD
    je      .op_add
    cmp     rbx, BINOP_SUB
    je      .op_sub
    cmp     rbx, BINOP_MUL
    je      .op_mul
    cmp     rbx, BINOP_DIV
    je      .op_div
    cmp     rbx, BINOP_MOD
    je      .op_mod
    cmp     rbx, BINOP_EQ
    je      .op_eq
    cmp     rbx, BINOP_NEQ
    je      .op_neq
    cmp     rbx, BINOP_LT
    je      .op_lt
    cmp     rbx, BINOP_GT
    je      .op_gt
    cmp     rbx, BINOP_LTE
    je      .op_lte
    cmp     rbx, BINOP_GTE
    je      .op_gte
    jmp     .op_add             ; default to add

.op_add:
    mov     rdi, cstr_33
    call    emit_str
    jmp     .emit_operands

.op_sub:
    mov     rdi, cstr_34
    call    emit_str
    jmp     .emit_operands

.op_mul:
    mov     rdi, cstr_35
    call    emit_str
    jmp     .emit_operands

.op_div:
    mov     rdi, cstr_36
    call    emit_str
    jmp     .emit_operands

.op_mod:
    mov     rdi, cstr_37
    call    emit_str
    jmp     .emit_operands

.op_eq:
    mov     rdi, cstr_38
    call    emit_str
    jmp     .emit_operands

.op_neq:
    mov     rdi, cstr_39
    call    emit_str
    jmp     .emit_operands

.op_lt:
    mov     rdi, cstr_40
    call    emit_str
    jmp     .emit_operands

.op_gt:
    mov     rdi, cstr_41
    call    emit_str
    jmp     .emit_operands

.op_lte:
    mov     rdi, cstr_42
    call    emit_str
    jmp     .emit_operands

.op_gte:
    mov     rdi, cstr_43
    call    emit_str

.emit_operands:
    ; Emit: %left_reg, %right_reg
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_44
    call    emit_str
    mov     rdi, r14
    call    emit_num
    mov     rdi, cstr_45
    call    emit_str

    pop     rax                 ; result register

    pop     r14
    pop     r13
    pop     r12
    pop     rbx
    pop     rbp
    ret

; ============================================================
; CODEGEN_UNARY
; Generates code for unary expression: -x, not x
; ============================================================
codegen_unary:
    push    rbp
    mov     rbp, rsp
    push    r12

    mov     r12, rdi

    ; Generate operand
    mov     rdi, [r12 + NODE_LEFT]
    call    codegen_node
    push    rax                 ; operand register

    call    new_reg
    push    rax                 ; result register

    mov     rdi, cstr_46
    call    emit_str
    mov     rdi, [rsp]
    call    emit_num

    mov     rax, [r12 + NODE_EXTRA]
    cmp     rax, 20             ; TOKEN_NOT
    je      .do_not

    ; Negate: sub 0, operand
    mov     rdi, cstr_47
    call    emit_str
    mov     rdi, [rsp + 8]
    call    emit_num
    jmp     .done_op

.do_not:
    mov     rdi, cstr_48
    call    emit_str
    mov     rdi, [rsp + 8]
    call    emit_num
    mov     rdi, cstr_49
    call    emit_str

.done_op:
    mov     rdi, cstr_50
    call    emit_str

    pop     rax
    add     rsp, 8              ; pop operand reg

    pop     r12
    pop     rbp
    ret

; ============================================================
; CODEGEN_IF
; Generates code for if/else statement
;
; LLVM IR output:
;   %cond = ... (condition)
;   br i1 %cond, label %if.then.N, label %if.else.N
;
;   if.then.N:
;     ... (then block)
;     br label %if.end.N
;
;   if.else.N:
;     ... (else block)
;     br label %if.end.N
;
;   if.end.N:
; ============================================================
codegen_if:
    push    rbp
    mov     rbp, rsp
    push    r12
    push    r13

    mov     r12, rdi            ; r12 = IF node

    ; Get unique label number
    mov     r13, [label_counter]
    inc     qword [label_counter]

    ; Generate condition
    mov     rdi, [r12 + NODE_LEFT]
    call    codegen_node
    push    rax                 ; save condition register

    ; Emit conditional branch
    mov     rdi, cstr_51
    call    emit_str
    pop     rdi
    call    emit_num
    mov     rdi, cstr_52
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_53
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_54
    call    emit_str

    ; Emit then block label
    mov     rdi, cstr_55
    call    emit_str
    mov     rdi, cstr_56
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_57
    call    emit_str

    ; Generate then block
    mov     rdi, [r12 + NODE_RIGHT]
    call    codegen_node

    ; Branch to end
    mov     rdi, cstr_58
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_59
    call    emit_str

    ; Emit else block label
    mov     rdi, cstr_60
    call    emit_str
    mov     rdi, cstr_61
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_62
    call    emit_str

    ; Generate else block (if exists)
    mov     rdi, [r12 + NODE_EXTRA]
    test    rdi, rdi
    jz      .no_else
    call    codegen_node

.no_else:
    ; Branch to end
    mov     rdi, cstr_63
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_64
    call    emit_str

    ; Emit end label
    mov     rdi, cstr_65
    call    emit_str
    mov     rdi, cstr_66
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_67
    call    emit_str

    xor     rax, rax
    pop     r13
    pop     r12
    pop     rbp
    ret

; ============================================================
; CODEGEN_WHILE
; Generates code for while loop
;
; LLVM IR output:
;   br label %while.cond.N
;
;   while.cond.N:
;     %cond = ... (condition)
;     br i1 %cond, label %while.body.N, label %while.end.N
;
;   while.body.N:
;     ... (body)
;     br label %while.cond.N
;
;   while.end.N:
; ============================================================
codegen_while:
    push    rbp
    mov     rbp, rsp
    push    r12
    push    r13

    mov     r12, rdi

    mov     r13, [label_counter]
    inc     qword [label_counter]

    ; Jump to condition check
    mov     rdi, cstr_68
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_69
    call    emit_str

    ; Condition label
    mov     rdi, cstr_70
    call    emit_str
    mov     rdi, cstr_71
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_72
    call    emit_str

    ; Generate condition
    mov     rdi, [r12 + NODE_LEFT]
    call    codegen_node
    push    rax

    ; Conditional branch
    mov     rdi, cstr_73
    call    emit_str
    pop     rdi
    call    emit_num
    mov     rdi, cstr_74
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_75
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_76
    call    emit_str

    ; Body label
    mov     rdi, cstr_77
    call    emit_str
    mov     rdi, cstr_78
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_79
    call    emit_str

    ; Generate body
    mov     rdi, [r12 + NODE_RIGHT]
    call    codegen_node

    ; Loop back to condition
    mov     rdi, cstr_80
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_81
    call    emit_str

    ; End label
    mov     rdi, cstr_82
    call    emit_str
    mov     rdi, cstr_83
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_84
    call    emit_str

    xor     rax, rax
    pop     r13
    pop     r12
    pop     rbp
    ret

; ============================================================
; CODEGEN_FOR
; Generates: for i in start..end { body }
;
; Clean implementation using dedicated BSS storage
; ============================================================
codegen_for:
    push    rbp
    mov     rbp, rsp
    push    rbx
    push    r12
    push    r13
    push    r14

    mov     r12, rdi            ; r12 = FOR node

    ; Get label number
    mov     r13, [label_counter]
    inc     qword [label_counter]

    ; Get range node
    mov     r14, [r12 + NODE_EXTRA]
    test    r14, r14
    jz      .done

    ; Save start and end node pointers BEFORE any codegen
    mov     rbx, [r14 + NODE_LEFT]    ; rbx = start node
    mov     r14, [r14 + NODE_RIGHT]   ; r14 = end node

    ; Generate start value
    mov     rdi, rbx
    call    codegen_node
    mov     [for_end_reg], rax        ; temporarily store start reg

    ; Generate end value
    mov     rdi, r14
    call    codegen_node
    ; rax = end register — save permanently
    push    rax                        ; [rsp] = end_reg

    ; Allocate counter on stack: %N = alloca i64
    call    new_reg
    mov     rbx, rax                   ; rbx = counter alloca reg
    mov     [for_ctr_alloca], rbx     ; save permanently

    ; emit: %counter = alloca i64
    mov     rdi, cstr_alloca_pfx      ; "  %"
    call    emit_str
    mov     rdi, rbx
    call    emit_num
    mov     rdi, cstr_alloca_sfx
    call    emit_str

    ; Store start into counter: store i64 %start, i64* %counter
    mov     rdi, cstr_store_pfx       ; "  store i64 %"
    call    emit_str
    mov     rdi, [for_end_reg]        ; start register
    call    emit_num
    mov     rdi, cstr_store_mid       ; ", i64* %"
    call    emit_str
    mov     rdi, rbx                   ; counter alloca
    call    emit_num
    mov     rdi, cstr_nl
    call    emit_str

    ; Register loop variable in var table
    mov     rdi, [r12 + NODE_LEFT]    ; IDENT node
    mov     rsi, rbx                   ; alloca register
    call    var_table_add

    ; Save end register permanently
    pop     rax                        ; restore end_reg
    mov     [for_end_reg], rax        ; save end register

    ; Jump to condition
    mov     rdi, cstr_br_label        ; "  br label %"
    call    emit_str
    mov     rdi, cstr_for_cond        ; "for.cond."
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_nl
    call    emit_str

    ; ── CONDITION LABEL ──────────────────────────────────
    mov     rdi, cstr_nl
    call    emit_str
    mov     rdi, cstr_for_cond        ; "for.cond."
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_colon_nl
    call    emit_str

    ; Load counter: %cur = load i64, i64* %counter
    call    new_reg
    mov     [for_cur_reg], rax        ; save cur_reg in BSS

    mov     rdi, cstr_pct
    call    emit_str
    mov     rdi, [for_cur_reg]
    call    emit_num
    mov     rdi, cstr_load_i64
    call    emit_str
    mov     rdi, [for_ctr_alloca]
    call    emit_num
    mov     rdi, cstr_nl
    call    emit_str

    ; Compare: %cmp = icmp slt i64 %cur, %end
    call    new_reg
    mov     [for_cmp_reg], rax        ; save cmp_reg in BSS

    mov     rdi, cstr_pct
    call    emit_str
    mov     rdi, [for_cmp_reg]
    call    emit_num
    mov     rdi, cstr_icmp_slt
    call    emit_str
    mov     rdi, [for_cur_reg]        ; cur_reg
    call    emit_num
    mov     rdi, cstr_comma_pct
    call    emit_str
    mov     rdi, [for_end_reg]        ; end register
    call    emit_num
    mov     rdi, cstr_nl
    call    emit_str

    ; Branch: br i1 %cmp, label %for.body.N, label %for.end.N
    ; Use BSS vars — no stack confusion

    mov     rdi, cstr_br_i1
    call    emit_str
    mov     rdi, [for_cmp_reg]        ; cmp register from BSS
    call    emit_num
    mov     rdi, cstr_lbl_comma       ; ", label %"
    call    emit_str
    mov     rdi, cstr_for_body_lbl    ; "for.body."
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_lbl_comma       ; ", label %"
    call    emit_str
    mov     rdi, cstr_for_end_lbl     ; "for.end."
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_nl
    call    emit_str

    ; ── BODY LABEL ───────────────────────────────────────
    mov     rdi, cstr_nl
    call    emit_str
    mov     rdi, cstr_for_body_lbl
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_colon_nl
    call    emit_str

    ; Generate body
    mov     rdi, [r12 + NODE_RIGHT]
    call    codegen_node

    ; ── INCREMENT ────────────────────────────────────────
    ; Load counter: %ld = load i64, i64* %counter
    call    new_reg
    mov     [for_loaded_reg], rax

    mov     rdi, cstr_pct
    call    emit_str
    mov     rdi, [for_loaded_reg]
    call    emit_num
    mov     rdi, cstr_load_i64
    call    emit_str
    mov     rdi, [for_ctr_alloca]
    call    emit_num
    mov     rdi, cstr_nl
    call    emit_str

    ; Add 1: %inc = add i64 %ld, 1
    call    new_reg
    mov     [for_inc_reg], rax

    mov     rdi, cstr_pct
    call    emit_str
    mov     rdi, [for_inc_reg]
    call    emit_num
    mov     rdi, cstr_add_i64_pct
    call    emit_str
    mov     rdi, [for_loaded_reg]
    call    emit_num
    mov     rdi, cstr_comma_1_nl
    call    emit_str

    ; Store: store i64 %inc, i64* %counter
    mov     rdi, cstr_store_pfx
    call    emit_str
    mov     rdi, [for_inc_reg]
    call    emit_num
    mov     rdi, cstr_store_mid
    call    emit_str
    mov     rdi, [for_ctr_alloca]
    call    emit_num
    mov     rdi, cstr_nl
    call    emit_str

; Loop back: br label %for.cond.N
    mov     rdi, cstr_br_label
    call    emit_str
    mov     rdi, cstr_for_cond
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_nl
    call    emit_str

    ; ── END LABEL ────────────────────────────────────────
    mov     rdi, cstr_nl
    call    emit_str
    mov     rdi, cstr_for_end_lbl
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_colon_nl
    call    emit_str

.done:
    xor     rax, rax
    pop     r14
    pop     r13
    pop     r12
    pop     rbx
    pop     rbp
    ret

; ============================================================
; CODEGEN_LOOP
; Generates code for infinite loop
; ============================================================
codegen_loop:
    push    rbp
    mov     rbp, rsp
    push    r12
    push    r13

    mov     r12, rdi

    mov     r13, [label_counter]
    inc     qword [label_counter]

    ; Jump to loop
    mov     rdi, cstr_125
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_126
    call    emit_str

    ; Loop label
    mov     rdi, cstr_127
    call    emit_str
    mov     rdi, cstr_128
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_129
    call    emit_str

    ; Generate body
    mov     rdi, [r12 + NODE_LEFT]
    call    codegen_node

    ; Loop back unconditionally
    mov     rdi, cstr_130
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_131
    call    emit_str

    ; End label (reached by break)
    mov     rdi, cstr_132
    call    emit_str
    mov     rdi, cstr_133
    call    emit_str
    mov     rdi, r13
    call    emit_num
    mov     rdi, cstr_134
    call    emit_str

    xor     rax, rax
    pop     r13
    pop     r12
    pop     rbp
    ret

; ============================================================
; CODEGEN_FN_DEF
; Generates code for function definition
;
; LLVM IR output:
;   define i64 @name() {
;   entry:
;     ... body ...
;     ret i64 0
;   }
; ============================================================
codegen_fn_def:
    push    rbp
    mov     rbp, rsp
    push    r12

    mov     r12, rdi            ; r12 = FN_DEF node

    ; Close current main function temporarily
    ; (functions are emitted after main in LLVM IR)
    ; For simplicity — emit function inline before main usage
    ; This works for non-recursive functions

    ; Close main first — add a ret
    mov     rdi, cstr_135
    call    emit_str
    mov     rdi, [label_counter]
    push    rdi
    inc     qword [label_counter]
    call    emit_num
    mov     rdi, cstr_136
    call    emit_str

    ; Function definition start
    ; Get function name from left child (IDENT node)
    mov     rax, [r12 + NODE_LEFT]

    mov     rdi, cstr_137
    call    emit_str
    mov     rdi, cstr_138
    call    emit_str

    ; Emit function name from source
    mov     rdi, [rax + NODE_TSTART]
    mov     rsi, [rax + NODE_TLEN]
    call    emit_source_text

    mov     rdi, cstr_139
    call    emit_str
    db      "entry:", 10, 0

    ; Generate function body (right child = block)
    mov     rdi, [r12 + NODE_RIGHT]
    call    codegen_node

    ; Function end
    mov     rdi, cstr_140
    call    emit_str
    db      "}", 10, 10, 0

    ; Resume main after function
    mov     rdi, cstr_141
    call    emit_str
    pop     rdi
    call    emit_num
    mov     rdi, cstr_142
    call    emit_str

    xor     rax, rax
    pop     r12
    pop     rbp
    ret

; ============================================================
; CODEGEN_FN_CALL
; Generates code for function call: name(args)
; ============================================================
codegen_fn_call:
    push    rbp
    mov     rbp, rsp
    push    r12

    mov     r12, rdi

    ; Allocate result register
    call    new_reg
    push    rax

    ; Emit: %reg = call i64 @name()
    mov     rdi, cstr_143
    call    emit_str
    mov     rdi, [rsp]
    call    emit_num
    mov     rdi, cstr_144
    call    emit_str

    ; Get function name from left child
    mov     rax, [r12 + NODE_LEFT]
    mov     rdi, [rax + NODE_TSTART]
    mov     rsi, [rax + NODE_TLEN]
    call    emit_source_text

    mov     rdi, cstr_145
    call    emit_str

    pop     rax
    pop     r12
    pop     rbp
    ret

; ============================================================
; CODEGEN_RETURN
; Generates code for return statement
; ============================================================
codegen_return:
    push    rbp
    mov     rbp, rsp
    push    r12

    mov     r12, rdi

    ; Check if there is a return value
    mov     rdi, [r12 + NODE_LEFT]
    test    rdi, rdi
    jz      .no_value

    ; Generate return expression
    call    codegen_node
    push    rax

    mov     rdi, cstr_146
    call    emit_str
    pop     rdi
    call    emit_num
    mov     rdi, cstr_147
    call    emit_str
    jmp     .done

.no_value:
    mov     rdi, cstr_148
    call    emit_str

.done:
    xor     rax, rax
    pop     r12
    pop     rbp
    ret

; ============================================================
; CODEGEN_BLOCK
; Generates code for a block: { statements }
; ============================================================
codegen_block:
    push    rbp
    mov     rbp, rsp
    push    r12

    mov     r12, [rdi + NODE_LEFT]  ; first statement

.stmt_loop:
    test    r12, r12
    jz      .done

    mov     rdi, r12
    call    codegen_node

    mov     r12, [r12 + NODE_NEXT]
    jmp     .stmt_loop

.done:
    xor     rax, rax
    pop     r12
    pop     rbp
    ret

; ============================================================
; EMIT_STRING_GLOBALS
; Emits all string literal global constants before main
; Must be called after main body is emitted but we insert
; them at the top using the pre-header buffer technique
; For simplicity we emit them inline at end of file
; ============================================================
emit_string_globals:
    push    rbp
    mov     rbp, rsp
    push    r12
    push    r13

    ; Check if any string literals
    mov     r13, [str_lit_count]
    test    r13, r13
    jz      .done

    ; Emit comment
    mov     rdi, cstr_149
    call    emit_str

    ; Loop through each string literal
    xor     r12, r12            ; index into str_lit_buf

.lit_loop:
    cmp     r12, r13
    jge     .done

    ; Get string info: start, len, index
    mov     rax, r12
    mov     rcx, 24             ; 3 * 8 bytes per entry
    mul     rcx

    mov     rbx, [str_lit_buf + rax]        ; source start
    mov     rcx, [str_lit_buf + rax + 8]    ; source length
    push    rcx                              ; save length

    ; Emit: @.str.N = private constant [LEN+1 x i8] c"TEXT\00"
    mov     rdi, cstr_150
    call    emit_str
    mov     rdi, r12
    call    emit_num

    mov     rdi, cstr_151
    call    emit_str

    ; length + 1 for null
    pop     rdi
    push    rdi
    inc     rdi
    call    emit_num

    mov     rdi, cstr_152
    call    emit_str

    ; Emit the actual string text from source
    pop     rsi                 ; length
    mov     rdi, rbx            ; start position
    call    emit_source_text

    ; Null terminator
    mov     rdi, cstr_153
    call    emit_str

    inc     r12
    jmp     .lit_loop

.done:
    pop     r13
    pop     r12
    pop     rbp
    ret

; ============================================================
; CODEGEN_WRITE_OUTPUT
; Writes the generated IR buffer to output.ll file
; ============================================================
codegen_write_output:
    push    rbp
    mov     rbp, rsp

    mov     rdi, msg_writing
    call    cg_print_str

    ; Open output file
    mov     rax, SYS_OPEN
    mov     rdi, out_filename
    mov     rsi, O_WRONLY | O_CREAT | O_TRUNC
    mov     rdx, 0o644
    syscall
    cmp     rax, 0
    jl      .error
    mov     [out_fd], rax

    ; Write IR buffer to file
    mov     rax, SYS_WRITE
    mov     rdi, [out_fd]
    mov     rsi, ir_buf
    mov     rdx, [ir_pos]
    syscall

    ; Close file
    mov     rax, SYS_CLOSE
    mov     rdi, [out_fd]
    syscall

    mov     rdi, msg_write_ok
    call    cg_print_str

    mov     rax, 1
    pop     rbp
    ret

.error:
    xor     rax, rax
    pop     rbp
    ret

; ============================================================
; VARIABLE TABLE FUNCTIONS
; ============================================================

; Add variable to table
; Input: rdi = IDENT node pointer
;        rsi = alloca register number
var_table_add:
    push    rbp
    mov     rbp, rsp
    push    rbx

    ; Get current count
    mov     rax, [var_count]
    cmp     rax, MAX_VAR_TABLE - 1
    jge     .overflow

    ; Calculate entry offset
    mov     rcx, VAR_ENTRY_SIZE
    mul     rcx
    lea     rbx, [var_table + rax]

    ; Store name start, name len, register
    mov     rax, [rdi + NODE_TSTART]
    mov     [rbx], rax
    mov     rax, [rdi + NODE_TLEN]
    mov     [rbx + 8], rax
    mov     [rbx + 16], rsi

    ; Increment count
    inc     qword [var_count]

.overflow:
    pop     rbx
    pop     rbp
    ret

; Look up variable in table
; Input: rdi = IDENT node pointer
; Returns: rax = alloca register number (0 if not found)
var_table_get:
    push    rbp
    mov     rbp, rsp
    push    rbx
    push    r12
    push    r13
    push    r14

    ; Get identifier info
    mov     r12, [rdi + NODE_TSTART]    ; name start in source
    mov     r13, [rdi + NODE_TLEN]      ; name length

    ; Search table
    xor     r14, r14                    ; index

.search_loop:
    cmp     r14, [var_count]
    jge     .not_found

    ; Get entry
    mov     rax, r14
    mov     rcx, VAR_ENTRY_SIZE
    mul     rcx
    lea     rbx, [var_table + rax]

    ; Compare lengths
    cmp     r13, [rbx + 8]
    jne     .next_entry

    ; Compare names
    mov     rdi, r12                    ; ident name in source
    mov     rsi, [rbx]                  ; stored name in source
    mov     rcx, r13                    ; length

    ; Both point into source buffer — compare
    mov     r8, [cg_src_buf]
    add     rdi, r8                     ; absolute pointer to ident
    add     rsi, r8                     ; absolute pointer to stored

    ; Compare character by character
    push    rcx
.char_loop:
    test    rcx, rcx
    jz      .match
    mov     al, [rdi]
    mov     ah, [rsi]
    cmp     al, ah
    jne     .char_no_match
    inc     rdi
    inc     rsi
    dec     rcx
    jmp     .char_loop

.match:
    pop     rcx
    ; Found — return register number
    mov     rax, [rbx + 16]
    jmp     .done

.char_no_match:
    pop     rcx

.next_entry:
    inc     r14
    jmp     .search_loop

.not_found:
    xor     rax, rax                    ; return 0 if not found

.done:
    pop     r14
    pop     r13
    pop     r12
    pop     rbx
    pop     rbp
    ret

; ============================================================
; REGISTER ALLOCATION
; ============================================================

; Allocate a new SSA register — returns next number
new_reg:
    mov     rax, [reg_counter]
    inc     qword [reg_counter]
    ret

; ============================================================
; IR EMISSION HELPERS
; ============================================================

; Emit null-terminated string to IR buffer
; Input: rdi = string pointer
emit_str:
    push    rbp
    mov     rbp, rsp
    push    rbx
    push    r12

    mov     r12, rdi
    xor     rbx, rbx

.len_loop:
    cmp     byte [r12 + rbx], 0
    je      .copy
    inc     rbx
    jmp     .len_loop

.copy:
    ; Copy to IR buffer
    push    rsi
    push    rdi
    push    rcx
    mov     rsi, r12
    mov     rdi, ir_pos
    mov     rax, [ir_pos]
    lea     rdi, [ir_buf + rax]
    mov     rcx, rbx
    rep movsb
    add     [ir_pos], rbx
    pop     rcx
    pop     rdi
    pop     rsi

    pop     r12
    pop     rbx
    pop     rbp
    ret

; emit_cstr is now an alias for emit_str
; Input: rdi = pointer to null-terminated string
emit_cstr:
    jmp     emit_str


; Emit a number (integer) to IR buffer
; Input: rdi = number to emit
emit_num:
    push    rbp
    mov     rbp, rsp
    push    rbx

    mov     rax, rdi
    test    rax, rax
    jnz     .not_zero

    ; Emit "0"
    mov     rax, [ir_pos]
    mov     byte [ir_buf + rax], '0'
    inc     qword [ir_pos]
    jmp     .done

.not_zero:
    ; Convert to decimal in temp buffer
    lea     rbx, [num_buf + 31]
    mov     byte [rbx], 0
    dec     rbx

.convert:
    test    rax, rax
    jz      .emit_digits
    xor     rdx, rdx
    mov     rcx, 10
    div     rcx
    add     dl, '0'
    mov     [rbx], dl
    dec     rbx
    jmp     .convert

.emit_digits:
    inc     rbx
    ; Copy to IR buffer
.digit_loop:
    cmp     byte [rbx], 0
    je      .done
    mov     rax, [ir_pos]
    mov     cl, [rbx]
    mov     [ir_buf + rax], cl
    inc     qword [ir_pos]
    inc     rbx
    jmp     .digit_loop

.done:
    pop     rbx
    pop     rbp
    ret

; Emit text from source buffer
; Input: rdi = start offset, rsi = length
emit_source_text:
    push    rbp
    mov     rbp, rsp
    push    rbx
    push    r12

    mov     r12, rdi            ; start offset
    mov     rbx, rsi            ; length

    test    rbx, rbx
    jz      .done

    ; Get source buffer pointer
    mov     rax, [cg_src_buf]
    add     rax, r12            ; absolute pointer to text

    ; Copy to IR buffer
    mov     rsi, rax
    mov     rax, [ir_pos]
    lea     rdi, [ir_buf + rax]

    push    rcx
    mov     rcx, rbx
    rep movsb
    pop     rcx

    add     [ir_pos], rbx

.done:
    pop     r12
    pop     rbx
    pop     rbp
    ret

; Print string to stdout
; Input: rdi = string pointer
cg_print_str:
    push    rbp
    mov     rbp, rsp
    push    rbx
    push    r12

    mov     r12, rdi
    xor     rbx, rbx
.len_loop:
    cmp     byte [r12 + rbx], 0
    je      .write
    inc     rbx
    jmp     .len_loop
.write:
    test    rbx, rbx
    jz      .done
    mov     rax, SYS_WRITE
    mov     rdi, STDOUT
    mov     rsi, r12
    mov     rdx, rbx
    syscall
.done:
    pop     r12
    pop     rbx
    pop     rbp
    ret
