# How to Put INK on GitHub — Simple Steps

Your INK repository is fully built and ready. Here's how to get it
online. Two ways: the **easy way** (website, no commands) and the
**developer way** (command line).

---

## THE EASY WAY (recommended to start — no commands)

### Step 1 — Make a GitHub account
Go to **github.com** and sign up (free). Use your IndianBrand email.

### Step 2 — Create a new repository
1. Click the **+** in the top-right corner → **New repository**
2. Owner: your account (or create an organization called **IndianBrand**)
3. Repository name: **ink**
4. Description: `INK — a small, safe, compiled programming language. Write the Future.`
5. Set it to **Public** (so others can see and use it)
6. Do NOT tick "Add a README" (we already have one)
7. Click **Create repository**

### Step 3 — Upload the files
1. On the new empty repo page, click **"uploading an existing file"**
   (it's a link in the middle of the page)
2. Unzip **INK_GitHub_Repo.zip** on your computer
3. Drag ALL the files and folders from inside the `INK` folder into
   the browser window
4. At the bottom, write: `First commit — INK v0.8`
5. Click **Commit changes**

Done! Your repo is now live at:
**github.com/YOUR_USERNAME/ink**

---

## THE DEVELOPER WAY (command line — for later)

If you or your engineer prefer the terminal:

```bash
# 1. Unzip the repo and go into it
unzip INK_GitHub_Repo.zip
cd INK

# 2. The git history is already set up — just add your GitHub as the remote
#    (replace YOUR_USERNAME with your GitHub name)
git remote add origin https://github.com/YOUR_USERNAME/ink.git

# 3. Push it up
git branch -M main
git push -u origin main
```

If it asks for a password, use a **Personal Access Token**
(GitHub → Settings → Developer settings → Personal access tokens),
not your account password.

---

## After it's online

1. **Check the README shows up** — GitHub displays it automatically
   on the main page. It should look clean with the feature table.

2. **Add topics** — on the repo page, click the gear next to "About"
   and add topics: `programming-language`, `compiler`, `assembly`,
   `llvm`, `india`. This helps people find INK.

3. **Share the link** — now you can send `github.com/YOUR_USERNAME/ink`
   to anyone: students, developers, the engineer you hire.

---

## What's in the repo

```
ink/
├── README.md          ← the front page (shows automatically)
├── LICENSE            ← MIT license
├── build.sh           ← builds the compiler
├── ink.sh             ← runs an INK program
├── lexer/             ← the lexer (Assembly)
├── parser/            ← the parser (Assembly)
├── codegen/           ← the code generator (Assembly)
├── main.asm           ← ties it together
├── examples/          ← 8 beginner programs to learn from
├── tests/             ← the test programs
└── docs/              ← the 3 Word documents (guide, words, phases)
```

---

## The most important next step

Once it's online, **give the link to 3-5 beginner programming
students** and ask each to write one small program — like "ask for
5 numbers and show the biggest." Watch where they get stuck. That
feedback is worth more than any new feature.

That is how INK grows from a working prototype into a language people
actually use.

**Jai Hind! 🇮🇳**
